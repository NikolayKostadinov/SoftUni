package P04HotelReservation;

public class ConsolePrinter {
    public static void print(double price) {
        System.out.printf("%.2f", price);
    }
}
