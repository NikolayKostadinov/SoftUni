package catHouse.entities.toys;

public class Mouse extends BaseToy{

    public static final int PRICE = 15;
    public static final int SOFTNESS = 5;

    public Mouse() {
        super(SOFTNESS, PRICE);
    }
}
