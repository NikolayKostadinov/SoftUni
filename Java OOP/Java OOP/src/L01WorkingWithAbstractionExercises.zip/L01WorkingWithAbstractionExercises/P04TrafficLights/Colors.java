package L01WorkingWithAbstractionExercises.P04TrafficLights;

public enum Colors {
    RED,
    GREEN,
    YELLOW;
}
