package L01WorkingWithAbstractionExercises.P04TrafficLights;

public class Pair {
    int a;
    String b;

    public Pair(int a, String b) {
        this.a = a;
        this.b = b;
    }
}
