package L01WorkingWithAbstractionExercises.P03CardsWithPower;

import output.ConsolePrinter;
import input.Reader;

public class Main {
    public static void main(String[] args) {
        Ranks rank = Ranks.valueOf(Reader.readLine());
        Suits suit = Suits.valueOf(Reader.readLine());
        Card card = new Card(rank, suit);
        ConsolePrinter.printLine(card.toString());
    }
}
