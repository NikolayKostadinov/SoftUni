package L01WorkingWithAbstractionExercises.P06GreedyTimes;

public class Main {
    public static void main(String[] args) {
        GreedySystem system = new GreedySystem();
        system.start();
    }
}