package L01WorkingWithAbstractionExercises.P05JediGalaxy;

public enum PlayerType {
    JEDI, EVIL
}
