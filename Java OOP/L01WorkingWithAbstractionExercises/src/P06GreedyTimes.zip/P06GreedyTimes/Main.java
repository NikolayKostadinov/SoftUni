
package P06GreedyTimes;

import input.Reader;

import java.util.LinkedHashMap;

public class Main {
    public static void main(String[] args) {

        long bagCapacity = Long.parseLong(Reader.readLine());
        String[] safe = Reader.readStringArray("\\s+");

        var bag = new LinkedHashMap<ItemType, LinkedHashMap<String, Long>>();
        long gold = 0;
        long gem = 0;
        long cash = 0;

        for (int i = 0; i < safe.length; i += 2) {
            String name = safe[i];
            long quantity = Long.parseLong(safe[i + 1]);

            ItemType itemType = ItemType.parseItemType(name);

            if (bagCapacity < gold + gem + cash + quantity) {
                continue;
            }

            switch (itemType) {
                case GEM:
                    if (!bag.containsKey(itemType)) {
                        if (bag.containsKey(ItemType.GOLD)) {
                            if (quantity > bag.get(ItemType.GOLD).values().stream().mapToLong(e -> e).sum()) {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    } else if (bag.get(itemType).values().stream().mapToLong(e -> e).sum() + quantity > bag.get(ItemType.GOLD).values().stream().mapToLong(e -> e).sum()) {
                        continue;
                    }
                    gem += quantity;
                    break;
                case CASH:
                    if (!bag.containsKey(itemType)) {
                        if (bag.containsKey(ItemType.GEM)) {
                            if (quantity > bag.get(ItemType.GOLD).values().stream().mapToLong(e -> e).sum()) {
                                continue;
                            }
                        } else {
                            continue;
                        }
                    } else if (bag.get(itemType).values().stream().mapToLong(e -> e).sum() + quantity > bag.get(ItemType.GEM).values().stream().mapToLong(e -> e).sum()) {
                        continue;
                    }
                    cash += quantity;
                    break;
                case GOLD:
                    gold += quantity;
                    break;
                case OTHER:
                    continue;
            }

            bag.putIfAbsent(itemType, new LinkedHashMap<>());
            bag.get(itemType).putIfAbsent(name, 0L);
            bag.get(itemType).put(name, bag.get(itemType).get(name) + quantity);
        }

        for (var x : bag.entrySet()) {
            Long sumValues = x.getValue().values().stream().mapToLong(l -> l).sum();

            System.out.println(String.format("<%s> $%s", x.getKey().getDisplayText(), sumValues));

            x.getValue().entrySet().stream().sorted((e1, e2) -> e2.getKey().compareTo(e1.getKey())).forEach(i -> System.out.println("##" + i.getKey() + " - " + i.getValue()));

        }
    }
}