package output;

public class ConsolePrinter {
    public static void printLine(String str) {
        System.out.println(str);
    }
}
