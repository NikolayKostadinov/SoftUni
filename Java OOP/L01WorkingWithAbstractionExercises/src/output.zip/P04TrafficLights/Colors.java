package P04TrafficLights;

public enum Colors {
    RED,
    GREEN,
    YELLOW;
}
