package P06MilitaryElite.entities;

import P06MilitaryElite.interfaces.Repair;

public class RepairImpl implements Repair {
    private String partName;
    private int hoursWorked;

    public RepairImpl(String partName, int hoursWorked) {
        this.partName = partName;
        this.hoursWorked = hoursWorked;
    }

    //    public RepairImpl(String partName, int hoursWorked){
//        this.setPartName(partName);
//        this.setHoursWorked(hoursWorked);
//    }
//
//    public String getPartName() {
//        return partName;
//    }
//
//    private void setPartName(String partName) {
//        if (partName.trim().isEmpty()) throw new IllegalArgumentException("Invalid partName");
//        this.partName = partName;
//    }
//
//    public int getHoursWorked() {
//        return hoursWorked;
//    }
//
//    private void setHoursWorked(int hoursWorked) {
//        if (hoursWorked < 0 ) throw new IllegalArgumentException("Invalid hoursWorked");
//        this.hoursWorked = hoursWorked;
//    }

    @Override
    public String toString() {
        return String.format("Part Name: %s Hours Worked: %d", this.partName, this.hoursWorked);
    }
}
