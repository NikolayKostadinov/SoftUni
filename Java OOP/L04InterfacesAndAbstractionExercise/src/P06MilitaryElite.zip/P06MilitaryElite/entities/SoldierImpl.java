package P06MilitaryElite.entities;

import P06MilitaryElite.interfaces.Soldier;

public abstract class SoldierImpl implements Soldier {
    private int id;
    private String firstName;
    private String lastName;

    public SoldierImpl(int id, String firstName, String lastName) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
    }

    //    private void setId(int id) {
//        if (id <= 0) throw new IllegalArgumentException("Id must be greater than 0");
//        this.id = id;
//    }
//
//    private void setFirstName(String firstName) {
//        if (firstName.trim().isEmpty()) throw new IllegalArgumentException("firstName must not be empty");
//        this.firstName = firstName;
//    }
//
//    private void setLastName(String lastName) {
//        if (lastName.trim().isEmpty()) throw new IllegalArgumentException("firstName must not be empty");
//        this.lastName = lastName;
//    }

    @Override
    public int getId() {
        return id;
    }

    @Override
    public String getFirstName() {
        return firstName;
    }

    @Override
    public String getLastName() {
        return lastName;
    }

    @Override
    public String toString() {
        return String.format("Name: %s %s Id: %d", this.firstName, this.lastName, this.id);
    }
}
