package P06MilitaryElite.interfaces;

import java.util.List;

public interface LieutenantGeneral {
    void addPrivate(Private priv);
    //List<Private> getPrivates();
}
