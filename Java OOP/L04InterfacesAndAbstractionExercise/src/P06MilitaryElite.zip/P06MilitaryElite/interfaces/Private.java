package P06MilitaryElite.interfaces;

public interface Private extends Soldier {
    double getSalary();
}
