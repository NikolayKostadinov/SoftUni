package P06MilitaryElite.interfaces;

public interface Mission {

}
