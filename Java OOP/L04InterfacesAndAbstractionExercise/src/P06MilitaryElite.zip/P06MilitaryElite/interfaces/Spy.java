package P06MilitaryElite.interfaces;

public interface Spy {
    String getCodeNumber();
}
