package P06MilitaryElite.interfaces;

import P06MilitaryElite.enums.Corps;

public interface SpecialisedSoldier {
    Corps getCorps();
}
