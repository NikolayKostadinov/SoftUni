package P07CollectionHierarchy.interfaces;

public interface AddRemovable extends Addable {
    String remove();
}
