package P07CollectionHierarchy.interfaces;

public interface Addable {
    int add(String element);
}
