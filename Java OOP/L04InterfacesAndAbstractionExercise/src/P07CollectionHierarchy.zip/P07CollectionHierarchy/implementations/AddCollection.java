package P07CollectionHierarchy.implementations;

import P07CollectionHierarchy.interfaces.Addable;

import java.util.ArrayDeque;
import java.util.Deque;

public class AddCollection implements Addable {

    private Deque<String> data;

    public AddCollection() {
        this.data = new ArrayDeque<>();
    }

    @Override
    public int add(String element) {
        this.data.offer(element);
        return this.data.size() - 1;
    }

    protected Deque<String> getData() {
        return data;
    }
}
