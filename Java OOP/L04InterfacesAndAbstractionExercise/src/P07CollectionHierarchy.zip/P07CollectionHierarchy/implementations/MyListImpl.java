package P07CollectionHierarchy.implementations;

import P07CollectionHierarchy.interfaces.MyList;

public class MyListImpl extends AddRemoveCollection
        implements MyList {

    @Override
    public int add(String element) {
        this.getData().push(element);
        return 0;
    }

    @Override
    public String remove() {
        return this.getData().pop();
    }

    @Override
    public int getUsed() {
        return this.getData().size();
    }
}
