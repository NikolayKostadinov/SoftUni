package P07CollectionHierarchy.implementations;

import P07CollectionHierarchy.interfaces.AddRemovable;

public class AddRemoveCollection extends AddCollection
        implements AddRemovable {

    @Override
    public int add(String element) {
        this.getData().offer(element);
        return 0;
    }

    @Override
    public String remove() {
        return this.getData().poll();
    }
}
