package P04FoodShortage;

public interface Birthable {
    String getBirthDate();
}
