package P05Тelephony;

public interface Callable {
    String call();
}
