package P07CollectionHierarchy;

public interface AddRemovable extends Addable {
    String remove();
}
