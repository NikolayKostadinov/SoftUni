package P05BorderControl;

public class Robot extends BaseIdentifiable {
    private String model;
    private String id;

    public Robot(String model, String id) {
        super(id);
        this.model = model;
    }

    public String getModel() {
        return model;
    }

}
