package P05BorderControl;

public class BaseIdentifiable implements Identifiable {
    private String id;

    public BaseIdentifiable(String id) {
        this.id = id;
    }

    @Override
    public String getId() {
        return id;
    }
}
