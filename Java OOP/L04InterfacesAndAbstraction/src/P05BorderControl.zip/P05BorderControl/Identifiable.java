package P05BorderControl;

public interface Identifiable {
    String getId();
}
