package P03SayHello;

public class Chinese extends PersonImpl{
    public Chinese(String name) {
        super(name);
    }

    @Override
    public String sayHello() {
        return "Djydjybydjy";
    }
}
