package P03SayHello;

public class European extends PersonImpl{
    public European(String name) {
        super(name);
    }
}
