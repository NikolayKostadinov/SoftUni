package P03StudentSystem;

import input.Reader;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        CommandHandler handler = new CommandHandler(new StudentRepository());
        StudentSystem studentSystem = new StudentSystem(handler);
        studentSystem.start();
    }
}
