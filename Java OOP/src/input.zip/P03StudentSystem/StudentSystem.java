package P03StudentSystem;

import input.Reader;

public class StudentSystem {
    private final CommandHandler handler;

    public StudentSystem(CommandHandler handler)
    {
        this.handler = handler;
    }

    public void start() {
        boolean isWorking = true;
        while (isWorking)
        {
            String result = handler.handleCommand(Reader.readStringArray("\\s+"));
            isWorking = !"Exit".equals(result);
            if (result!= null && !"Exit".equals(result)){
                System.out.println(result);
            }
        }
    }
}
