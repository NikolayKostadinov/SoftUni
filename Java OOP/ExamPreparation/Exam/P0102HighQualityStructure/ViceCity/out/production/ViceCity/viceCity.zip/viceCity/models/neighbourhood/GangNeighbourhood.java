package viceCity.models.neighbourhood;

import viceCity.models.guns.Gun;
import viceCity.models.players.Player;

import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.stream.Collectors;

public class GangNeighbourhood implements Neighbourhood {
    @Override
    public void action(Player mainPlayer, Collection<Player> civilPlayers) {
        // mainPlayerShot
        Collection<Gun> guns = mainPlayer.getGunRepository().getModels().stream().filter(Gun::canFire).collect(Collectors.toList());
        List<Player> alivePayers = getAlivePayers(civilPlayers);
        shutToCivilPlayers(guns, alivePayers);
        alivePayers = getAlivePayers(alivePayers);
        shutToMainPlayer(alivePayers, mainPlayer);

    }

    private List<Player> getAlivePayers(Collection<Player> civilPlayers) {
        return civilPlayers.stream().filter(Player::isAlive).collect(Collectors.toList());
    }

    private void shutToMainPlayer(List<Player> alivePayers, Player mainPlayer) {
        if (mainPlayer.isAlive()) {
            for (Player alivePayer : alivePayers) {
                List<Gun> guns = alivePayer.getGunRepository().getModels().stream().filter(Gun::canFire).collect(Collectors.toList());
                for (Gun gun : guns) {
                    mainPlayer.takeLifePoints(gun.fire());
                    if (!mainPlayer.isAlive()) return;
                }
            }
        }
    }

    private void shutToCivilPlayers(Collection<Gun> guns, List<Player> alivePayers) {
        if (!alivePayers.isEmpty() && !guns.isEmpty()) {
            Player civilPlayer = alivePayers.iterator().next();
            for (Gun gun : guns) {
                while (gun.canFire() && alivePayers.iterator().hasNext()) {
                    civilPlayer.takeLifePoints(gun.fire());
                    if (!civilPlayer.isAlive()) {
                        civilPlayer = alivePayers.iterator().next();
                    }
                }

                if (!alivePayers.iterator().hasNext()) break;
            }
        }
    }
}
