package bakery.repositories.interfaces;

import bakery.entities.tables.interfaces.Table;

import java.util.ArrayList;
import java.util.Collection;

public class TableRepositoryImpl extends BaseRepository<Table> implements TableRepository<Table>{
    public TableRepositoryImpl(Collection<Table> models) {
        super(new ArrayList<>());
    }

    @Override
    public Table getByNumber(int number) {
        return this.getAll().stream().filter(t->t.getTableNumber() == number).findFirst().orElse(null);
    }
}
