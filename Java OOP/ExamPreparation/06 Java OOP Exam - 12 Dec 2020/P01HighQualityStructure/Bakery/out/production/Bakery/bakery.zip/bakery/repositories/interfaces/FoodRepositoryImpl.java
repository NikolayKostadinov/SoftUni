package bakery.repositories.interfaces;

import bakery.entities.bakedFoods.interfaces.BakedFood;

import java.util.ArrayList;

public class FoodRepositoryImpl extends BaseRepository<BakedFood> implements FoodRepository<BakedFood>{
    public FoodRepositoryImpl() {
        super(new ArrayList<>());
    }

    @Override
    public BakedFood getByName(String name) {
        return this.getAll().stream().filter(f->f.getName().equals(name)).findFirst().orElse(null);
    }
}
