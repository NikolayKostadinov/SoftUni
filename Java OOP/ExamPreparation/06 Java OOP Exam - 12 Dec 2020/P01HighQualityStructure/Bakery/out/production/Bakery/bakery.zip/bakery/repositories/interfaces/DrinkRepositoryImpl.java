package bakery.repositories.interfaces;

import bakery.entities.drinks.interfaces.Drink;

import java.util.ArrayList;
import java.util.Collection;

public class DrinkRepositoryImpl extends BaseRepository<Drink> implements DrinkRepository<Drink>{
    public DrinkRepositoryImpl(Collection<Drink> models) {
        super(new ArrayList<>());
    }

    @Override
    public Drink getByNameAndBrand(String drinkName, String drinkBrand) {
        return this.getAll()
                .stream()
                .filter(d->d.getName().equals(drinkName) && d.getBrand().equals(drinkBrand))
                .findFirst()
                .orElse(null);
    }
}
