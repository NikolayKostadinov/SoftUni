package glacialExpedition.models.explorers;

public class NaturalExplorer extends BaseExplorer{
    private static final double INITIAL_UNITS_ENERGY = 60;
    private static final double DECREASE = 7;

    protected NaturalExplorer(String name) {
        super(name, INITIAL_UNITS_ENERGY);
    }

    @Override
    public void search() {
        double resultEnergy = this.getEnergy() - DECREASE;
        resultEnergy = (resultEnergy < 0) ? 0 : resultEnergy;
        this.setEnergy(resultEnergy);
    }
}
