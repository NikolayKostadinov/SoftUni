package glacialExpedition.models.explorers;

public class NaturalExplorer extends BaseExplorer {
    private static final double INITIAL_ENERGY = 60;
    private static final double STEP_DOWN = 15;

    public NaturalExplorer(String name) {
        super(name, INITIAL_ENERGY);
    }

    @Override
    public void search() {
        double resultEnergy = this.getEnergy() - STEP_DOWN;
        resultEnergy = (resultEnergy < 0) ? 0 : resultEnergy;
        this.setEnergy(resultEnergy);
    }
}
