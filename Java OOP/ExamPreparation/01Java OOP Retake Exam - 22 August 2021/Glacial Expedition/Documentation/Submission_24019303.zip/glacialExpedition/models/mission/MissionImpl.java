package glacialExpedition.models.mission;

import glacialExpedition.models.explorers.Explorer;
import glacialExpedition.models.states.State;

import java.util.Collection;
import java.util.stream.Collectors;

public class MissionImpl implements Mission{

    @Override
    public void explore(State state, Collection<Explorer> explorers) {
        explorers.stream()
                .filter(ex->ex.canSearch())
                .forEach(explorer ->
                {
                    while (explorer.canSearch()){
                        if (state.getExhibits().isEmpty()) return;
                        explorer.search();
                        String exhibit = state.getExhibits().stream().findFirst().orElse(null);
                        explorer.getSuitcase().getExhibits().add(exhibit);
                        state.getExhibits().remove(exhibit);
                    }
                });
    }
}
