package glacialExpedition.models.explorers;

import glacialExpedition.models.suitcases.Suitcase;

public abstract class BaseExplorer implements Explorer {
    private static final double STEP_DOWN = 15;
    private String name;
    private double energy;
    private Suitcase suitcase;

    public BaseExplorer(String name, double energy) {
        this.setName(name);
        this.setEnergy(energy);
    }

    protected void setName(String name) {
        if (name == null || name.trim().isEmpty()) {
            throw new NullPointerException("Explorer name cannot be null or empty.");
        }
        this.name = name;
    }

    protected void setEnergy(double energy) {
        if (energy < 0) {
            throw new IllegalArgumentException("Cannot create Explorer with negative energy.");
        }
        this.energy = energy;
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public double getEnergy() {
        return this.energy;
    }

    @Override
    public Suitcase getSuitcase() {
        return this.suitcase;
    }

    @Override
    public boolean canSearch() {
        return this.energy > 0;
    }

    @Override
    public void search() {
        double resultEnergy = this.energy - STEP_DOWN;
        this.energy = (resultEnergy < 0) ? 0 : resultEnergy;
    }
}
