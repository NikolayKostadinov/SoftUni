import java.util.ArrayDeque;

public class Test {
    public static void main(String[] args) {
        ArrayDeque<Integer> test = new ArrayDeque<>();
    }
}
