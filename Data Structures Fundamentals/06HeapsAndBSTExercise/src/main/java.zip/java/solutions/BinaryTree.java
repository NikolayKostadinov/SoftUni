package solutions;

import java.util.ArrayList;
import java.util.List;

public class BinaryTree {
    private final int key;
    private final BinaryTree left;
    private final BinaryTree right;


    public BinaryTree(int key, BinaryTree first, BinaryTree second) {
        this.key = key;
        this.left = first;
        this.right = second;
    }

    public Integer findLowestCommonAncestor(int first, int second) {
        List<Integer> firstPath = findPath(this, first);
        List<Integer> secondPath = findPath(this, second);

        int smallerSize = Math.min(firstPath.size(), secondPath.size());

        int i = 0;
        for (; i < smallerSize; i++) {
            if (!firstPath.get(i).equals(secondPath.get(i))) {
                break;
            }
        }

        return firstPath.get(i - 1);
    }

    private List<Integer> findPath(BinaryTree binaryTree, int element) {
        List<Integer> path = new ArrayList<>();
        findNodePath(binaryTree, element, path);
        return path;
    }

    private boolean findNodePath(BinaryTree binaryTree, int element, List<Integer> path) {
        if (binaryTree == null) return false;
        if (binaryTree.key == element) return true;
        path.add(binaryTree.key);
        boolean leftResult = findNodePath(binaryTree.left, element, path);
        if (leftResult) {
            return true;
        }

        boolean rightResult = findNodePath(binaryTree.right, element, path);
        if (rightResult) {
            return true;
        }
        path.remove(Integer.valueOf(binaryTree.key));
        return false;
    }

    public List<Integer> topView() {
        return null;
    }
}
