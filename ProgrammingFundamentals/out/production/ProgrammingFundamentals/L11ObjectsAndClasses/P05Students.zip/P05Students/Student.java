package P05Students;

public class Student {
    String firstName;
    String lastName;
    int age;
    String hometown;

    public Student(String firstName, String lastName, int age, String hometown) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.age = age;
        this.hometown = hometown;
    }

    @Override
    public String toString(){
        return String.format("%s %s is %d years old", this.firstName, this.lastName, this.age);
    }
}
