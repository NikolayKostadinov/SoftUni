package com.manhattan.services.interfaces;
public interface Service {
    void execute();
}
