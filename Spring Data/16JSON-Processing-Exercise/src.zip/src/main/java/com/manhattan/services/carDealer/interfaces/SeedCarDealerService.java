package com.manhattan.services.carDealer.interfaces;

import com.manhattan.services.common.SeedService;

public interface SeedCarDealerService extends SeedService {
}
