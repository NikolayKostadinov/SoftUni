package com.manhattan.services.common;

import java.io.IOException;

public interface SeedService {
    void seed() throws IOException;
}
