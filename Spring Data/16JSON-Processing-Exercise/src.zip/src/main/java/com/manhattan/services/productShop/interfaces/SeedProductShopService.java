package com.manhattan.services.productShop.interfaces;

import com.manhattan.services.common.SeedService;

public interface SeedProductShopService extends SeedService {

}
