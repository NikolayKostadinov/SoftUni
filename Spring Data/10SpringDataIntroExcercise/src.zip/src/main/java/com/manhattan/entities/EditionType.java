package com.manhattan.entities;

public enum EditionType {
    NORMAL, PROMO, GOLD
}
