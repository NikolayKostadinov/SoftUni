package com.manhattan.entities;

public enum AgeRestriction {
    MINOR, TEEN, ADULT
}
