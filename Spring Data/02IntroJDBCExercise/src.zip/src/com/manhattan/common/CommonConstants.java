package com.manhattan.common;

public class CommonConstants {
    public static final String ANSI_RED = "\u001B[31m";
    public static final String ANSI_RESET = "\u001B[0m";
    public static final String CONNECTION_STRING = "jdbc:mysql://localhost:3306/";
    public static final String DATABASE = "minions_db";
}
