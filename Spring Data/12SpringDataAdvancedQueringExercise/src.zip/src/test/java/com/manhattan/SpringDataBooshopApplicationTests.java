package com.manhattan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringDataBooshopApplicationTests {

    @Test
    void contextLoads() {
    }

}
