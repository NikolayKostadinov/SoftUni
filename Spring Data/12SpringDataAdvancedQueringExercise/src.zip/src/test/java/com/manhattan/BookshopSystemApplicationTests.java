package com.manhattan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookshopSystemApplicationTests {

    @Test
    void contextLoads() {
    }

}
