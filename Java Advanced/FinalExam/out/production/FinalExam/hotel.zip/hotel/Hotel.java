package hotel;

import java.util.LinkedHashMap;
import java.util.Map;
import java.util.stream.Collectors;

public class Hotel {
    private String name;
    private int capacity;
    private final Map<String, Person> roster;

    public Hotel(String name, int capacity) {
        this.name = name;
        this.capacity = capacity;
        this.roster = new LinkedHashMap<>();
    }

    public void add(Person person){
        if (this.roster.size() < this.capacity){
            this.roster.put(person.getName(), person);
        }
    }

    public boolean remove(String name){
        if (!this.roster.containsKey(name)) return false;
        this.roster.remove(name);
        return true;
    }

    public Person getPerson(String name, String hometown){
        if (this.roster.containsKey(name)){
            Person person = this.roster.get(name);
            if (person.getHometown().equals(hometown)){
                return person;
            }
        }

        return null;
    }

    public int getCount(){
        return this.roster.size();
    }

    public String getStatistics(){
        return String.format("The people in the hotel %s are:", this.name) +
                (this.roster.isEmpty() ? "" :
                        System.lineSeparator() +
                        this.roster.values()
                                .stream()
                                .map(Person::toString)
                                .collect(Collectors.joining(System.lineSeparator())));
    }
}
