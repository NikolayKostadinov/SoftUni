package cafe;

public class Employee implements Comparable<Employee> {
    private String name;
    private int age;
    private String country;

    public String getName() {
        return name;
    }

    public int getAge() {
        return age;
    }

    public Employee(String name, int age, String country) {
        this.name = name;
        this.age = age;
        this.country = country;
    }

    @Override
    public String toString() {
        return String.format("Employee: %s, %s from %s", name, age, country);
    }

    @Override
    public int compareTo(Employee o) {
        return this.age - o.age;
    }
}
